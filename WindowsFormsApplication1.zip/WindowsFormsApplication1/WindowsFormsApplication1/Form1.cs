﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. CREAR LA CONEXIÓN
                // Usamos "ServiceReference1" porque así se llama en TU imagen (carpeta Service References).
                // "WebService1SoapClient" es el nombre de la clase de tu servicio.
                ServiceReference1.WebService1SoapClient cliente = new ServiceReference1.WebService1SoapClient();

                // 2. PEDIR LOS DATOS
                // En tu versión (VS2012) esto es directo. No necesitas "await" ni ".Body".
                // Te devuelve la lista limpia.
                var lista = cliente.ListarAlumnos();

                // 3. MOSTRAR EN LA TABLA
                // Asegúrate de tener un DataGridView en tu formulario (por defecto se llama dataGridView1)
                dataGridView1.DataSource = lista;

                MessageBox.Show("¡Datos cargados correctamente!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar: " + ex.Message);
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e) { }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}