﻿namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.btnSumar = new System.Windows.Forms.Button();
            this.lblResultadoSuma = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.btnFibo = new System.Windows.Forms.Button();
            this.lblResultadoFibo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(57, 69);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(56, 20);
            this.txtA.TabIndex = 0;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(160, 69);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(66, 20);
            this.txtB.TabIndex = 1;
            // 
            // btnSumar
            // 
            this.btnSumar.Location = new System.Drawing.Point(104, 110);
            this.btnSumar.Name = "btnSumar";
            this.btnSumar.Size = new System.Drawing.Size(65, 33);
            this.btnSumar.TabIndex = 2;
            this.btnSumar.Text = "sumar";
            this.btnSumar.UseVisualStyleBackColor = true;
            this.btnSumar.Click += new System.EventHandler(this.btnSumar_Click);
            // 
            // lblResultadoSuma
            // 
            this.lblResultadoSuma.AutoSize = true;
            this.lblResultadoSuma.Location = new System.Drawing.Point(115, 38);
            this.lblResultadoSuma.Name = "lblResultadoSuma";
            this.lblResultadoSuma.Size = new System.Drawing.Size(35, 13);
            this.lblResultadoSuma.TabIndex = 3;
            this.lblResultadoSuma.Text = "label1";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(105, 262);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(64, 20);
            this.txtCantidad.TabIndex = 4;
            // 
            // btnFibo
            // 
            this.btnFibo.Location = new System.Drawing.Point(91, 303);
            this.btnFibo.Name = "btnFibo";
            this.btnFibo.Size = new System.Drawing.Size(91, 25);
            this.btnFibo.TabIndex = 5;
            this.btnFibo.Text = "Calcular Serie";
            this.btnFibo.UseVisualStyleBackColor = true;
            this.btnFibo.Click += new System.EventHandler(this.btnFibo_Click_1);
            // 
            // lblResultadoFibo
            // 
            this.lblResultadoFibo.AutoSize = true;
            this.lblResultadoFibo.Location = new System.Drawing.Point(115, 219);
            this.lblResultadoFibo.Name = "lblResultadoFibo";
            this.lblResultadoFibo.Size = new System.Drawing.Size(35, 13);
            this.lblResultadoFibo.TabIndex = 6;
            this.lblResultadoFibo.Text = "label2";
            this.lblResultadoFibo.Click += new System.EventHandler(this.lblResultadoFibo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 353);
            this.Controls.Add(this.lblResultadoFibo);
            this.Controls.Add(this.btnFibo);
            this.Controls.Add(this.txtCantidad);
            this.Controls.Add(this.lblResultadoSuma);
            this.Controls.Add(this.btnSumar);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Button btnSumar;
        private System.Windows.Forms.Label lblResultadoSuma;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.Button btnFibo;
        private System.Windows.Forms.Label lblResultadoFibo;
    }
}

