﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        // -------------------------------------------------------------------------
        //  FALTA ESTO: Instanciar la conexión al servicio
        // -------------------------------------------------------------------------

        // NOTA IMPORTANTE:
        // "localhost" es el nombre que se pone por defecto si agregaste una "Referencia Web".
        // Si al agregar la referencia le pusiste otro nombre (ej. "MiReferencia"), cambia "localhost" por ese nombre.
        // "WebService1" es el nombre de la clase que pusiste en tu código del servidor.

        ServiceReference1.WebService1SoapClient servicio = new ServiceReference1.WebService1SoapClient();

        // SI USASTE "Agregar referencia de servicio" (la moderna), la línea sería así:
        // ServiceReference1.WebService1SoapClient servicio = new ServiceReference1.WebService1SoapClient();
        // -------------------------------------------------------------------------

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSumar_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtA.Text);
                int b = int.Parse(txtB.Text);

                // Ahora sí, "servicio" existe y funciona
                int resultado = servicio.SumarNumeros(a, b);

                lblResultadoSuma.Text = "Resultado: " + resultado.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en los números: " + ex.Message);
            }
        }



        private void lblResultadoFibo_Click(object sender, EventArgs e)
        {

        }

        private void btnFibo_Click_1(object sender, EventArgs e)
        {
            try
            {
                int n = int.Parse(txtCantidad.Text);

                // 1. Llamamos al servicio
                var serie = servicio.CalcularFibonacci(n);

                // 2. Verificación universal (usa Count() en vez de Length para evitar errores)
                if (serie == null || serie.Count() == 0)
                {
                    MessageBox.Show("El servidor devolvió una lista vacía.");
                    return;
                }

                // 3. Conversión segura a texto
                // Usamos .ToArray() al final para asegurar compatibilidad
                string resultadoTexto = string.Join(" - ", serie.Select(x => x.ToString()).ToArray());

                lblResultadoFibo.Text = "Serie: " + resultadoTexto;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error: " + ex.Message);
            }

        }
    }
}