﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;

namespace test_3
{
    /// <summary>
    /// Descripción breve de WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }

        public class Alumno
        {
            public string Ci { get; set; }
            public string Paterno { get; set; }
            public string Materno { get; set; }
            public string Nombre { get; set; }
        }

        // CADENA DE CONEXIÓN:
        // "Data Source=.\SQLEXPRESS" suele ser más seguro que "localhost\SQLEXPRESS"
        // "Integrated Security=True" usa tu usuario de Windows (no pide contraseña)
        private string connectionString = @"Data Source=DESKTOP-TABAPHA;Initial Catalog=AlumnoDB;Integrated Security=True";

        [WebMethod]
        public List<Alumno> ListarAlumnos()
        {
            List<Alumno> alumnos = new List<Alumno>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Consulta SQL estándar
                string query = "SELECT ci, paterno, materno, nombre FROM Alumno";

                SqlCommand cmd = new SqlCommand(query, con);

                try
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            alumnos.Add(new Alumno
                            {
                                // Es buena práctica usar ToString() para evitar errores si hay nulos
                                Ci = reader["ci"].ToString(),
                                Paterno = reader["paterno"].ToString(),
                                Materno = reader["materno"].ToString(),
                                Nombre = reader["nombre"].ToString()
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Si falla la conexión, al menos no se cierra el programa de golpe.
                    // Aquí podrías loguear el error: ex.Message
                }
            }

            return alumnos;
        }
    }
}
