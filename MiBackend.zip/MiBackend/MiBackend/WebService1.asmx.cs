﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace MiBackend
{
    /// <summary>
    /// Descripción breve de WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }

        // --- MÉTODO 1: SUMA ---
        [WebMethod]
        public int SumarNumeros(int a, int b)
        {
            return a + b;
        }

        // --- MÉTODO 2: FIBONACCI ---
        // Fórmula: F_n = F_{n-1} + F_{n-2}
        [WebMethod]
        public List<int> CalcularFibonacci(int limite)
        {
            List<int> serie = new List<int>();
            int a = 0, b = 1, c = 0;

            for (int i = 0; i < limite; i++)
            {
                serie.Add(a);
                c = a + b;
                a = b;
                b = c;
            }
            return serie;
        }

    }
}
